package com.slk;

import java.io.IOException;
import javax.servlet.Servlet;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebServlet;


@WebServlet({ "/Testing", "/welcome" })
public class Testing implements Servlet {

	
	public void init(ServletConfig config) throws ServletException {
		System.out.println("inside init");
	}

	
	public void destroy() {
		System.out.println("inside destroy");
		
	}

	
	public ServletConfig getServletConfig() {
		return null;
		
	}

	
	public String getServletInfo() {
		return null;
		
	}

	
	public void service(ServletRequest request, ServletResponse response) throws ServletException, IOException {
		System.out.println("inside service");
	}

}
