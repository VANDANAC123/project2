package com.slk.training.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.slk.training.entity.Product;

//1import javax.sql.DataSource;

import java.sql.PreparedStatement;

//@Component("jdbc") 
public class ProductDaoJdbcImpl implements ProductDao {
	private String driver;
	private String url;
	private String user;
	private String password;
//@Autowired(required=false)
	private DataSource dataSource;

	public ProductDaoJdbcImpl() {
		System.out.println(" an object of ProductDaoJdbcImpl is created using default constructor");
	}

	public ProductDaoJdbcImpl(DataSource dataSource) {
		System.out.println("ProductDaoJdbcImpl is created using the overload");
		this.dataSource = dataSource;
	}

	public void setDataSource(DataSource dataSource) {
		this.dataSource = dataSource;
	}

//string can call constructor via constructor-injection
	public ProductDaoJdbcImpl(String driver, String url, String user, String password) {
		// System.out.println("ProductDaoJdbcImpl(driver, url, user, password) called");
		this.driver = driver;
		this.url = url;
		this.user = user;
		this.password = password;
	}

	// string can call any setter via property injection (setter injection)
	// a setter is also knowm as the writable property ofr a mutator
	// if the name of the setter is setdriver but the property is driver
	public void setDriver(String driver) {
		this.driver = driver;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public void setUser(String user) {
		this.user = user;
	}

//setter property called "jdbcinfo"
	public void setJdbcInfo(String[] info) {
		driver = info[0];
		url = info[1];
		user = info[2];
		password = info[3];
	}

	public void setJdbcMap(Map<String, String> map) {
		driver = map.get("jdbc.driver");
		url = map.get("jdbc.url");
		user = map.get("jdbc.user");
		password = map.get("jdbc.password");

	}

	public void setPassword(String password) {
		this.password = password;
	}

	private Connection openConnection() throws SQLException, ClassNotFoundException {

		if (dataSource != null) {
			return dataSource.getConnection();
		}

		Class.forName(driver);
		return DriverManager.getConnection(url, user, password);
	}

	@Override
	public int count() throws DaoException {
		String sql = "select count(*) from product";
		try (Connection conn = openConnection();

				PreparedStatement stmt = conn.prepareStatement(sql);
				ResultSet rs = stmt.executeQuery();) {
			rs.next();
			return rs.getInt(1);
		} catch (Exception ex) {
			throw new DaoException(ex);
		}
	}

	@Override
	public void addProduct(Product product) throws DaoException {
		String sql = "insert into product values(?,?,?,?)";
		try (Connection conn = openConnection();

				PreparedStatement stmt = conn.prepareStatement(sql);
				) {
			stmt.setInt(1, product.getId());
			stmt.setString(2, product.getName());
			stmt.setString(3, product.getCategory());
			stmt.setDouble(4, product.getPrice());
			stmt.executeUpdate();
		} catch (Exception ex) {

			throw new DaoException(ex);
		}

	}

	@Override
	public Product getProduct(int id) throws DaoException {
		String sql = "select * from product where id=?";
		try (Connection conn = openConnection();

				PreparedStatement stmt = conn.prepareStatement(sql);) {
			stmt.setInt(1, id);
			ResultSet rs = stmt.executeQuery();

			while (rs.next()) {
				Product p = new Product();
				p.setId(rs.getInt("id"));
				p.setName(rs.getString("name"));
				p.setCategory(rs.getString("category"));
				p.setPrice(rs.getDouble("price"));

				return p;
			}
			return null;

		} catch (Exception ex) {
			throw new DaoException(ex);
		}

	}

	@Override
	public void updateProduct(Product product) throws DaoException {
		String sql = "delete from product where id=?";
		try (Connection conn = openConnection();

				PreparedStatement stmt = conn.prepareStatement(sql);)

		{
			stmt.setInt(1,product.getId());
			//stmt.setString(2, product.getName());
			//stmt.setString(3, product.getCategory());
				//stmt.setDouble(3, product.getPrice());
			
			stmt.executeUpdate();
			addProduct(product);
			
	//	stmt.setString(1, product.getName());
		//stmt.setString(2, product.getCategory());
		//	stmt.setDouble(3, product.getPrice());
//			stmt.setInt(1, product.getId());
//			stmt.executeQuery();
		//stmt.executeUpdate();

		} catch (Exception ex) {
			throw new DaoException(ex);
		}

	}

	@Override
	public void deleteProduct(int id) throws DaoException {
		String sql = "delete from product where id=?";
		try (Connection conn = openConnection();

				PreparedStatement stmt = conn.prepareStatement(sql);) {
			stmt.setInt(1, id);
			stmt.executeUpdate();
		} catch (Exception ex) {
			throw new DaoException(ex);
		}

	}

	@Override
	public List<Product> getAllProducts() throws DaoException {
		String sql = "select * from product";
		List<Product> list = new ArrayList<>();

		try (

				Connection conn = openConnection();

				PreparedStatement stmt = conn.prepareStatement(sql);
				ResultSet rs = stmt.executeQuery();)

		{
			while (rs.next()) {
				Product p = new Product();
				p.setId(rs.getInt("id"));
				p.setName(rs.getString("name"));
				p.setCategory(rs.getString("category"));
				p.setPrice(rs.getDouble("price"));
				list.add(p);
			}

		}

		catch (Exception ex) {
			throw new DaoException(ex);
		}

		return list;
	}

	@Override
	public List<Product> getProductsByPriceRange(double min, double max) throws DaoException {
		String sql = "select * from product where price between ? and ?";
		List<Product> list = new ArrayList<>();

		try (Connection conn = openConnection();

				PreparedStatement stmt = conn.prepareStatement(sql);)

		{
			stmt.setDouble(1, min);
			stmt.setDouble(2, max);
			ResultSet rs = stmt.executeQuery();

			while (rs.next())

			{
				Product p = new Product();
				p.setId(rs.getInt("id"));
				p.setName(rs.getString("name"));
				p.setCategory(rs.getString("category"));
				p.setPrice(rs.getDouble("price"));
				list.add(p);
			}

		} catch (Exception ex) {
			throw new DaoException(ex);
		}
		return list;
	}

	@Override
	public List<Product> getProductsByCategory(String category) throws DaoException {
		String sql = "select * from product where category=?";
		List<Product> list = new ArrayList<>();

		try (Connection conn = openConnection();

				PreparedStatement stmt = conn.prepareStatement(sql);) {
			stmt.setString(1, category);
			ResultSet rs = stmt.executeQuery();

			while (rs.next()) {
				Product p = new Product();
				p.setId(rs.getInt("id"));
				p.setName(rs.getString("name"));
				p.setCategory(rs.getString("category"));
				p.setPrice(rs.getDouble("price"));
				list.add(p);


			}

		}

		catch (Exception ex) {
			throw new DaoException(ex);
		}
		return list;
	}
}
