package com.slk.training.programs;

import java.util.List;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.slk.training.dao.DaoException;
import com.slk.training.dao.ProductDao;
import com.slk.training.entity.Product;

public class MainProgram {
	public static void main(String[] args) throws DaoException {

		ClassPathXmlApplicationContext ctx;

		ctx = new ClassPathXmlApplicationContext("context1.xml");
		ProductDao dao = ctx.getBean("jdbc", ProductDao.class);
	int pc = dao.count();
		System.out.println("there are " + pc + " products");
		Product p ;
		p = dao.getProduct(1);		System.out.println(" id: " + p.getId() + " name: " + p.getName() + " category: " + p.getCategory() + " price: "
				+ p.getPrice());

		List<Product> p1 = dao.getAllProducts();
	for (int i = 0; i < p1.size(); i++) {
		Product p2 = (Product) p1.get(i);
		System.out.println(p2);
	}
	Product p4= new Product(3,"mi","mobile",	7890.0);
		
		dao.updateProduct(p4);
		
		List<Product> list=dao.getProductsByCategory("mobile");
		for(int i=0;i<list.size();i++) {
			
			Product p2 = (Product) list.get(i);
			System.out.println(p2);
		}
		 List<Product>list1=dao. getProductsByPriceRange(1000,5678);
		 for(int i=0;i<list.size();i++) {
				
				Product p2 = (Product) list1.get(i);
		System.out.println(p2);
			}
		 
	 Product p6=new Product(7,"duster","car",4567);
	 dao.addProduct(p6);
	 
		 p = dao.getProduct(7);
		System.out.println(" id: " + p.getId() + " name: " + p.getName() + " category: " + p.getCategory() + " price: "
			+ p.getPrice());

		List<Product> p19 = dao.getAllProducts();
	for (int i = 0; i < p19.size(); i++) {			
		Product p2 = (Product) p19.get(i);
			System.out.println(p2);
			}
		
	//dao.deleteProduct(7);
		
		

		ctx.close();
	}
}
