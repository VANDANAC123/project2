package com.slk.training.cfg;

import javax.sql.DataSource;

import org.apache.commons.dbcp2.BasicDataSource;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.core.JdbcTemplate;

@Configuration
@ComponentScan(basePackages= {"com.slk.training.dao"})
public class AppConfig5 {


	@Bean
	public DataSource dbcp() {
		BasicDataSource bds = new BasicDataSource();
		bds.setDriverClassName("org.h2.Driver");
		bds.setUrl("jdbc:h2:tcp://localhost/~/slk_training_2018_12");
		bds.setPassword("");
		bds.setUsername("sa");
		bds.setInitialSize(10);
		bds.setMaxTotal(100);
		return bds;
	}
	
	@Bean
	public JdbcTemplate template(DataSource ds)//dependency injection
	{
		JdbcTemplate tp1=new JdbcTemplate(ds);//manual wiring via constructor
		return tp1;
	}
}
