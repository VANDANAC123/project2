package com.slk.training.cfg;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.slk.training.dao.ProductDaoJdbcImpl;


@Configuration
public class AppConfig1 {
 //a bean is defined by returning an object of a class from a function
	@Bean
public ProductDaoJdbcImpl jdbc() {
	ProductDaoJdbcImpl dao=new ProductDaoJdbcImpl();
	dao.setDriver("org.h2.Driver");
	dao.setUrl("jdbc:h2:tcp://localhost/~/slk_training_2018_12");
	dao.setPassword("");
	dao.setUser("sa");
	return dao;
}
}
