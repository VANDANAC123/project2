package com.slk.training.cfg;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.dbcp2.BasicDataSource;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Component;

import com.slk.training.dao.ProductDaoJdbcImpl;

@Configuration
@ComponentScan(basePackages= {"com.slk.training.dao" })
public class AppConfig4 {
	// a bean is defined by returning an object of a class from a function
	@Bean(name= {"dbcp","dataSource"})
	public  BasicDataSource dcbp() {
		BasicDataSource bds=new BasicDataSource();
		bds.setDriverClassName("org.h2.Driver");
		bds.setPassword("");
		bds.setUsername("sa");
		bds.setUrl("jdbc:h2:tcp://localhost/~/slk_training_2018_12");
		bds.setInitialSize(10);
		bds.setMaxTotal(100);
		return bds;
	
		
	}
	
	
	
	
	
	

}
