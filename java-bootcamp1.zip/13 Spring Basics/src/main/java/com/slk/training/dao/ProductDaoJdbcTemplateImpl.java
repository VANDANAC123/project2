package com.slk.training.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.slk.training.entity.Product;
@Repository
public class ProductDaoJdbcTemplateImpl implements ProductDao{
	@Autowired(required=false)
	private JdbcTemplate template;
	
	private Product toProduct(ResultSet rs) throws SQLException
	{
		Product p=new Product();
			p.setId(rs.getInt("id"));
		p.setName(rs.getString("name"));
		p.setCategory(rs.getString("category"));
		p.setPrice(rs.getDouble("price"));
		return p;
	}

	@Override
	public void addProduct(Product product) throws DaoException {
		try {
			String sql="insert into product values(?,?,?,?)";
			template.update(sql,product.getId(),product.getName(),product.getCategory(),product.getPrice());
		} catch (DataAccessException e) {
			throw new DaoException(e);
		}
		
	}

	@Override
	public Product getProduct(int id) throws DaoException {
	String sql="select * from product where id=?";
	return template.queryForObject(sql,(rs,index)->toProduct(rs),id);
	}

	@Override
	public void updateProduct(Product product) throws DaoException {
		String sql="update product set name=?,category=?,price=? where id=? ";
		template.update(sql,product.getId(),product.getName(),product.getCategory(),product.getPrice());
		
	}

	@Override
	public void deleteProduct(int id) throws DaoException {
		try {
			String sql="delete from product where id=?";
			template.update(sql);
		} catch (DataAccessException e) {
			throw new DaoException();
		}
		
		
	}

	@Override
	public int count() throws DaoException {
		String sql="select count(*) from product";
	return template.queryForObject(sql,Integer.class);
	 
	}

	@Override
	public List<Product> getAllProducts() throws DaoException {
		String sql="select * from product";
		List<Product> list=template.query(sql,(rs,index)->toProduct(rs));
		return list;
		
	}

	@Override
	public List<Product> getProductsByPriceRange(double min, double max) throws DaoException {
		String sql="select * from product where price between ? and?";
		
		return template.query(sql, (rs,index)->toProduct(rs),min,max);
	}

	@Override
	public List<Product> getProductsByCategory(String category) throws DaoException {
		String sql="select * from product where category=?";
		List<Product> list=template.query(sql,(rs,index)->toProduct(rs),category);
		return list;
	}

	

}
