package com.slk.training.dao;

import com.slk.training.entity.Product;
import java.util.List;

public interface ProductDao {
	
	public Product getProductById(int id) throws DaoException;
	
	public List getAllProducts() throws DaoException;
	
	public List getProductsByCategory(String category) throws DaoException;
	
	
	

}
