package com.slk.training.web;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet({ "/AddNewProduct", "/add-name" })
public class AddNewProduct extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.getRequestDispatcher("/WEB-INF/pages/name-form.jsp").forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String name = request.getParameter("name");
		//session scope
		HttpSession session = request.getSession();
		//application scope
		ServletContext ctx=getServletContext();
		System.out.println("session.isnew()=" + session.isNew());
		System.out.println("session.getid()=" + session.getId());
		System.out.println();
		List<String> nameslist=(List<String>) session.getAttribute("names");
		List<String> nameslist2=(List<String>) ctx.getAttribute("names");
		if (nameslist==null) {
			nameslist = new ArrayList<String>();
			session.setAttribute("names", nameslist);

		}
		if (nameslist2==null) {
			nameslist2 = new ArrayList<String>();
			ctx.setAttribute("names", nameslist2);
		}
		
			
		nameslist.add(name);
		nameslist2.add(name);
		response.sendRedirect("./");

	}

}
